package com.dao;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.Register;
import org.h2.command.dml.*;

@Repository  
@Transactional
public class RegisterDAOImpl  implements RegisterDAO{
	
	@Autowired(required=true)
	private SessionFactory sessionfactory;
	

	
	public List<Register> list() {

		@SuppressWarnings("unchecked")
		List<Register> listRegister = (List<Register>) sessionfactory.getCurrentSession().createCriteria(Register.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return listRegister;
	}

	
	public Register get(String Fname) {

		String hql = "from R_Userwhere id " + Fname+ " ";

		Query query = (Query) sessionfactory.getCurrentSession().createQuery(hql);
		List<Register> listRegister = (List<Register>) query.list();

		if (listRegister != null || listRegister.isEmpty()) {
			return listRegister.get(0);
		}

		return null;
	}

	
	public void re(Register Register) {
		// TODO Auto-generated method stub
		sessionfactory.getCurrentSession().saveOrUpdate(Register);
	}

	
	public void delete(String id) {
		// TODO Auto-generated method stub
		Register RegisterToDelete = new Register();
		RegisterToDelete.setAge(id);
		sessionfactory.getCurrentSession().delete(RegisterToDelete);
	}

	

}



