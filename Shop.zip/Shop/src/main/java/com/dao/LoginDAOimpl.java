package com.dao;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.Login;

@Repository
@Transactional

public class LoginDAOimpl  implements LoginDAO{
@Autowired(required=true)
private SessionFactory sessionFactory;

public boolean check(Login lo) {
		boolean isvalidLogin=false;
		Query q=(Query) sessionFactory.openSession().createQuery("from log where name='"+lo.getName()+"'").list();	
		@SuppressWarnings("unchecked")
			List<Login> l= q.list();
		int s=l.size();
		if(s==1)
		{
			isvalidLogin=true;
		}
		return isvalidLogin;
	}
public void disc(Login lo) {
	
			sessionFactory.getCurrentSession().saveOrUpdate(lo);

		}  
		// TODO Auto-generated method stub
		
	}
	



