package com.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.model.Category;
import com.model.Product;
import com.service.CategoryService;


@Controller
public class CategoryController {

	@Autowired
	CategoryService categoryService;

	public CategoryController() {
		// super();
		// TODO Auto-generated constructor stub
		System.out.println("category controller");
	}

	@RequestMapping("/category")
	public ModelAndView gotoCategory(@ModelAttribute("categ") Category categ) {
		List categoryList = categoryService.getList();
		return new ModelAndView("category", "CategoryList", categoryList);
		
	}
	@RequestMapping(value = "saveCategory", method = RequestMethod.POST)
	public ModelAndView getForm(@ModelAttribute("categ") Category categ,String s) {
		categoryService.insertRow(categ,s);
		List categoryList = categoryService.getList();
		return new ModelAndView("category", "CategoryList", categoryList);
	}

	// @RequestMapping("register")
	// public ModelAndView registerUser(@ModelAttribute Category category) {
	// categoryService.insertRow(category);
	// return new ModelAndView("redirect:list");
	// }

	@RequestMapping("list1")
	public ModelAndView getList() {
		List categoryList = categoryService.getList();
		return new ModelAndView("list1", "CategoryList", categoryList);
	}

	@RequestMapping("deleteCategory")
	public ModelAndView deleteUser(@ModelAttribute("categ")Category categ,@RequestParam int id) {
		categoryService.deleteRow(id);
		List categoryList = categoryService.getList();
		return new ModelAndView("category","CategoryList", categoryList);
	}

	@RequestMapping("/editcategory")
	public ModelAndView editUser(@ModelAttribute("categ") Category categ, @RequestParam int id) 
	{
		categ = categoryService.getRowById(id);
		List categoryList = categoryService.getList();
		return new ModelAndView("editcategory", "CategoryObject", categoryList);
	}

	@RequestMapping("updateCategory")
	public ModelAndView updateUser(@ModelAttribute("categ") Category categ) {
		categoryService.updateRow(categ);
		List categoryList = categoryService.getList();
		return new ModelAndView("redirect:category");
	}
	@RequestMapping("/listcategory")
	public @ResponseBody ModelAndView getlistcategory(ModelMap m)
	{
		List<Category> list=categoryService.getList();
		Gson gson=new Gson();
		String st=gson.toJson(list);
		m.addAttribute("div",st);
		System.out.println("Json"+st);
		 return new ModelAndView("listcategory");
	}



	/*@RequestMapping(value = "saveCategory", method = RequestMethod.POST)
	public ModelAndView getForm(@ModelAttribute("categ") Product categ,ModelMap m) 
	{
		
		
			  MultipartFile file = categ.getFile(); 
			  String fileName = "";
			  
			  String image="";
			  if(!file.isEmpty())		 
			  {
				  try 
				  {
					  System.out.println("inside try");
				  fileName = file.getOriginalFilename();
				  byte[] filesize=file.getBytes();
				  BufferedOutputStream bout=new BufferedOutputStream(new FileOutputStream(new File("D:\\eclipse work\\ShoppingCart\\src\\main\\webapp\\resources\\photo\\" + fileName)));
				   bout.write(filesize);
				   bout.close();
				   image="/resources/photo/"+fileName;
				   //r.setAttribute("img",image);
				   m.addAttribute("img",image);
				   System.out.println("upload success.."+image);
				  }
				   catch (IOException e) {
				   // TODO Auto-generated catch block
					  System.out.println("upload failed..");
				   e.printStackTrace();
				  }
				 
		  
	  }
	  
	  return new ModelAndView("addCategory", "message", fileName);
}
*/
}
