package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.RegisterDAO;
import com.model.Register;

@Service
@Transactional
public class RegisterServiceImpl implements RegisterService {
        @Autowired(required=true)
	private RegisterDAO registerDAO;
		
		public void r(Register register) {
			
			registerDAO.re(register);
			
		}

		public void save(Object ob) {
			// TODO Auto-generated method stub
			
		}

		public void edit(Object ob) {
			// TODO Auto-generated method stub
			
		

		
		
		}
}

