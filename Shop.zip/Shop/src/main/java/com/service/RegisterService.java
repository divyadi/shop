package com.service;


import com.model.Register;

public interface RegisterService<BornUser> {
	public void r(Register register);

	public void save(BornUser ob);
public void edit(BornUser ob);



 

}
