package com.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dao.CategoryDAO;
import com.model.Category;


@Service("categoryService")
@Transactional(propagation = Propagation.SUPPORTS)
public class CategoryServiceImpl implements CategoryService{
	
	@Autowired(required=true)
	private CategoryDAO categoryDAO;

	public int insertRow(Category categ,String s) {
		// TODO Auto-generated method stub
		return  categoryDAO.insertRow(categ,s);
		 
	}

	public List getList() {
		// TODO Auto-generated method stub
		return categoryDAO.getList();
	}

	public Category getRowById(int id) {
		// TODO Auto-generated method stub
		return  categoryDAO.getRowById(id);
	}

	public int updateRow(Category categ) {
		// TODO Auto-generated method stub
		return  categoryDAO.updateRow(categ);
	}

	public int deleteRow(int id) {
		// TODO Auto-generated method stub
		return  categoryDAO.deleteRow(id);
	}
}
