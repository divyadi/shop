package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
@Entity(name="Log")
@Component
public class Login {
	@Id
	public String Username;
	public String getName() {
		return Username;
	}
	public void setName(String Username) {
		this.Username = Username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String password;
	

}