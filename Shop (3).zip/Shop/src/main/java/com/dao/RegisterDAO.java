package com.dao;


import com.model.Register;

public interface RegisterDAO {
	
	public void re(Register reg);

	
}



