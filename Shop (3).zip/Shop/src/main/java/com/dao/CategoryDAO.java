package com.dao;

import java.util.List;

import com.model.Category;



public interface CategoryDAO {

		 public List getList();
		 public Category getRowById(int id);
		 public int updateRow(Category categ);
		 public int deleteRow(int id);
		 public int insertRow(Category categ,String s);
	}


