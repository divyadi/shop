package com.service;

import com.model.Login;

public interface LoginService {
	public boolean check(Login lo);
	public void disc(Login lo);
}
