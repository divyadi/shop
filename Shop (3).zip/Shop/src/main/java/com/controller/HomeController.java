package com.controller;



import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.model.Login;
import com.model.Register;
import com.service.LoginService;
import com.service.RegisterService;

@Controller
public class HomeController {
	@Autowired(required = true)
	LoginService ls;
	@Autowired(required = true)
	RegisterService rs;


	@RequestMapping("/")
	public String getHome() {
		return "index";

	}

	@RequestMapping("/exception")
	private String he()
	{
		return "exception";
	}
	@RequestMapping("/welcome")
	private String hellos()
	{
		return "welcome";
	}
	@RequestMapping("/confirmDetails")
	private String hello()
	{
		return "confirmDetails";
	}
	@RequestMapping("/memberDetails")
	private String gu()
	{
		return "memberDetails";
	}


	@RequestMapping("/contact")
	private String hel()
	{
		return "contact";
	}
	@RequestMapping("/bangles")
	private String jump()
	{
		return "bangles";
	}


    @RequestMapping("/login")
	public String hun()
    {
    	
		return "login";
	}
	

	@RequestMapping( "/chain")
	public String gun() {
		return "chain";
	}
	@RequestMapping("/index1")
	private String time()
	{
		return "index1";
	}

	@RequestMapping("/rings")
	public String mon() {
		return "rings";
	}
	
	@RequestMapping("/home")
	public String sun() {
		return "home";
	}
	
	



	

	@RequestMapping(value = "/fSignup")
	public String getregister() {
		return "Registration";
	}

	@ModelAttribute("Registration")
	public Register gt() {
		return new Register();
	}

	@RequestMapping(value = "/Signup", method = RequestMethod.POST)
	public ModelAndView reguser(@ModelAttribute("Registration") Register register) {
		System.out.println(register);
		ModelAndView mc = new ModelAndView("index");
		rs.r(register);
		return mc;
		
		
		
	}
	
	@RequestMapping(value="/checkLogin",method=RequestMethod.POST)
	public String validateLogin(HttpServletRequest r)
	{
		String v=r.getParameter("username");
		String p=r.getParameter("password");
		if((v.equals("meenak"))&&(p.equals("1234"))){
			return "index";
		}
		else
		{
			return "home";
		}
	}
		
	
	
	
}
	

 